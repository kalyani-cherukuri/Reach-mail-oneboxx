import { Badge } from '@/components/ui/badge';
import { EmailCategory } from '@/types/email';
import { CheckCircle2, Calendar, XCircle, AlertTriangle, Clock } from 'lucide-react';

interface EmailCategoryBadgeProps {
  category: EmailCategory;
  className?: string;
}

const categoryConfig = {
  'interested': {
    label: 'Interested',
    icon: CheckCircle2,
    variant: 'default' as const,
    className: 'bg-interested text-interested-foreground hover:bg-interested/90',
  },
  'meeting-booked': {
    label: 'Meeting Booked',
    icon: Calendar,
    variant: 'default' as const,
    className: 'bg-meeting-booked text-meeting-booked-foreground hover:bg-meeting-booked/90',
  },
  'not-interested': {
    label: 'Not Interested',
    icon: XCircle,
    variant: 'default' as const,
    className: 'bg-not-interested text-not-interested-foreground hover:bg-not-interested/90',
  },
  'spam': {
    label: 'Spam',
    icon: AlertTriangle,
    variant: 'default' as const,
    className: 'bg-spam text-spam-foreground hover:bg-spam/90',
  },
  'out-of-office': {
    label: 'Out of Office',
    icon: Clock,
    variant: 'default' as const,
    className: 'bg-out-of-office text-out-of-office-foreground hover:bg-out-of-office/90',
  },
  'uncategorized': {
    label: 'Uncategorized',
    icon: Clock,
    variant: 'secondary' as const,
    className: 'bg-muted text-muted-foreground',
  },
};

export function EmailCategoryBadge({ category, className }: EmailCategoryBadgeProps) {
  const config = categoryConfig[category];
  const Icon = config.icon;

  return (
    <Badge variant={config.variant} className={`${config.className} ${className} gap-1`}>
      <Icon className="h-3 w-3" />
      {config.label}
    </Badge>
  );
}
