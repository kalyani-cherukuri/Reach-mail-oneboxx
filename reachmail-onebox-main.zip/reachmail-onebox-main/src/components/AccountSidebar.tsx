import { EmailAccount, EmailFolder } from '@/types/email';
import { Button } from '@/components/ui/button';
import { 
  Inbox, 
  Send, 
  FileText, 
  Mail,
  Plus,
  ChevronDown,
  Circle
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState } from 'react';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

interface AccountSidebarProps {
  accounts: EmailAccount[];
  folders: EmailFolder[];
  selectedAccountId?: string;
  selectedFolder?: string;
  onSelectAccount: (accountId: string) => void;
  onSelectFolder: (folder: string, accountId: string) => void;
}

const folderIcons: Record<string, React.ElementType> = {
  'Inbox': Inbox,
  'Sent': Send,
  'Drafts': FileText,
};

export function AccountSidebar({
  accounts,
  folders,
  selectedAccountId,
  selectedFolder,
  onSelectAccount,
  onSelectFolder,
}: AccountSidebarProps) {
  const [openAccounts, setOpenAccounts] = useState<Set<string>>(
    new Set(accounts.map(a => a.id))
  );

  const toggleAccount = (accountId: string) => {
    const newSet = new Set(openAccounts);
    if (newSet.has(accountId)) {
      newSet.delete(accountId);
    } else {
      newSet.add(accountId);
    }
    setOpenAccounts(newSet);
  };

  return (
    <aside className="w-64 border-r border-border bg-sidebar flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Mail className="h-5 w-5 text-primary" />
            Onebox
          </h2>
        </div>
        <Button className="w-full bg-primary hover:bg-primary/90" size="sm">
          <Plus className="h-4 w-4 mr-2" />
          Add Account
        </Button>
      </div>

      {/* Accounts List */}
      <div className="flex-1 overflow-y-auto p-2">
        {accounts.map((account) => {
          const accountFolders = folders.filter(f => f.accountId === account.id);
          const isOpen = openAccounts.has(account.id);

          return (
            <Collapsible
              key={account.id}
              open={isOpen}
              onOpenChange={() => toggleAccount(account.id)}
              className="mb-2"
            >
              <CollapsibleTrigger asChild>
                <Button
                  variant="ghost"
                  className="w-full justify-start px-2 hover:bg-accent"
                >
                  <ChevronDown
                    className={cn(
                      "h-4 w-4 mr-2 transition-transform",
                      !isOpen && "-rotate-90"
                    )}
                  />
                  <div className="flex-1 text-left">
                    <div className="font-medium text-sm">{account.name}</div>
                    <div className="text-xs text-muted-foreground">{account.email}</div>
                  </div>
                  {account.unreadCount > 0 && (
                    <span className="text-xs font-semibold bg-primary text-primary-foreground rounded-full px-2 py-0.5">
                      {account.unreadCount}
                    </span>
                  )}
                </Button>
              </CollapsibleTrigger>
              
              <CollapsibleContent className="pl-4 space-y-1">
                {accountFolders.map((folder) => {
                  const Icon = folderIcons[folder.name] || Circle;
                  const isSelected = selectedAccountId === account.id && selectedFolder === folder.name;

                  return (
                    <Button
                      key={folder.id}
                      variant="ghost"
                      className={cn(
                        "w-full justify-start px-2 text-sm hover:bg-accent",
                        isSelected && "bg-accent text-accent-foreground"
                      )}
                      onClick={() => onSelectFolder(folder.name, account.id)}
                    >
                      <Icon className="h-4 w-4 mr-2" />
                      <span className="flex-1 text-left">{folder.name}</span>
                      {folder.count > 0 && (
                        <span className="text-xs text-muted-foreground">
                          {folder.count}
                        </span>
                      )}
                    </Button>
                  );
                })}
              </CollapsibleContent>
            </Collapsible>
          );
        })}
      </div>
    </aside>
  );
}
