export type EmailCategory = 
  | 'interested' 
  | 'meeting-booked' 
  | 'not-interested' 
  | 'spam' 
  | 'out-of-office'
  | 'uncategorized';

export interface Email {
  id: string;
  from: {
    name: string;
    email: string;
  };
  subject: string;
  preview: string;
  body: string;
  date: Date;
  read: boolean;
  starred: boolean;
  category: EmailCategory;
  folder: string;
  accountId: string;
}

export interface EmailAccount {
  id: string;
  email: string;
  name: string;
  provider: string;
  unreadCount: number;
}

export interface EmailFolder {
  id: string;
  name: string;
  count: number;
  accountId: string;
}
