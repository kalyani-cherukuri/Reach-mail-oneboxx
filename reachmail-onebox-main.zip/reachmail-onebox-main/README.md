# 📧 Onebox Email Aggregator Backend  
### Assignment – Associate Backend Engineer | ReachInbox

## 🚀 Overview
This project implements a **feature-rich Onebox Email Aggregator** backend using **TypeScript + Node.js**, designed to synchronize multiple IMAP accounts in real-time, index and categorize emails using AI, and provide integrations with **Elasticsearch**, **Slack**, and **Webhooks**.

The architecture is modular, production-ready, and easily extensible — built to demonstrate backend engineering skills in handling real-time email processing, data indexing, and AI-driven automation.

---

## 🏗️ Features Implemented

### ✅ 1. Real-Time IMAP Sync
- Supports syncing **multiple IMAP accounts** (minimum 2).
- Fetches **last 30 days** of emails on first sync.
- Uses **persistent IMAP IDLE** connections for real-time updates (no polling or cron jobs).
- Extracts:
  - `subject`, `from`, `to`, `date`, `folder`, and `attachments metadata`.

### ✅ 2. Searchable Storage (Elasticsearch)
- Uses **Dockerized Elasticsearch** for indexing and searching emails.
- Custom mapping for full-text search, folder & account filtering.
- REST APIs for:
  - `GET /emails` → Search and filter emails.
  - `GET /emails/:id` → Get specific email details.

### ✅ 3. AI-Based Categorization
- Each new email is auto-categorized into:
  `Interested | Meeting Booked | Not Interested | Spam | Out of Office`.
- Supports:
  - **OpenAI-based LLM categorization** (if `OPENAI_API_KEY` provided)
  - **Offline rule-based fallback** (no API key needed).
- Stores category + confidence score in Elasticsearch.

### ✅ 4. Slack & Webhook Integration
- Sends **Slack notifications** when an email is categorized as `Interested`.
- Triggers **external webhook** (e.g., [webhook.site](https://webhook.site)) for automation.
- Async, retryable background jobs handled using **BullMQ**.

### ✅ 5. API Endpoints (Postman Ready)
| Method | Endpoint | Description |
|--------|-----------|-------------|
| `POST` | `/accounts` | Add IMAP account credentials |
| `POST` | `/sync/:accountId` | Trigger initial sync for an account |
| `GET` | `/emails` | Search emails (supports filters + pagination) |
| `GET` | `/emails/:id` | Fetch detailed email data |
| `POST` | `/emails/:id/label` | Override/update email label |
| `GET` | `/health` | Health check endpoint |

Includes **Postman collection** for testing all routes.

### ✅ 6. (Bonus) AI-Powered Suggested Replies (RAG)
- Stores example outreach/product data in a **vector store** (pgvector/Weaviate/in-memory FAISS fallback).
- Uses **Retrieval-Augmented Generation (RAG)** with OpenAI to suggest replies.
- Endpoint:
