import { Email } from '@/types/email';
import { EmailCategoryBadge } from './EmailCategoryBadge';
import { Button } from '@/components/ui/button';
import { 
  Reply, 
  Forward, 
  Trash2, 
  Archive, 
  Star,
  MoreVertical,
  Clock,
  Sparkles
} from 'lucide-react';
import { format } from 'date-fns';
import { Separator } from '@/components/ui/separator';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface EmailDetailProps {
  email: Email;
}

export function EmailDetail({ email }: EmailDetailProps) {
  return (
    <div className="flex-1 flex flex-col h-full">
      {/* Header */}
      <div className="border-b border-border bg-card p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <EmailCategoryBadge category={email.category} />
              <span className="text-xs text-muted-foreground">
                {email.folder}
              </span>
            </div>
            <h1 className="text-2xl font-semibold mb-2">{email.subject}</h1>
          </div>
          
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon">
              <Star className={email.starred ? "fill-primary text-primary" : ""} />
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>Mark as unread</DropdownMenuItem>
                <DropdownMenuItem>Move to folder</DropdownMenuItem>
                <DropdownMenuItem>Export</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* From/To/Date */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
              <span className="text-sm font-semibold text-primary">
                {email.from.name.charAt(0).toUpperCase()}
              </span>
            </div>
            <div className="flex-1">
              <div className="font-semibold">{email.from.name}</div>
              <div className="text-sm text-muted-foreground">{email.from.email}</div>
            </div>
            <div className="text-sm text-muted-foreground flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {format(email.date, 'MMM d, yyyy • h:mm a')}
            </div>
          </div>
        </div>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-3xl">
          <div className="prose prose-invert prose-sm max-w-none">
            {email.body.split('\n').map((paragraph, index) => (
              <p key={index} className="mb-4 text-foreground leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>
        </div>
      </div>

      <Separator />

      {/* AI Suggested Reply */}
      {email.category === 'interested' && (
        <div className="border-t border-border bg-accent/20 p-4">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-sm font-semibold">AI Suggested Reply</span>
            </div>
            <div className="bg-card border border-border rounded-lg p-4 mb-3">
              <p className="text-sm">
                Hi {email.from.name.split(' ')[0]},
                <br /><br />
                Thank you for your interest in ReachInbox! I'd be happy to schedule a demo to show you how our AI-driven platform can help scale your outreach efforts.
                <br /><br />
                You can book a convenient time here: https://cal.com/reachinbox
                <br /><br />
                Looking forward to speaking with you!
              </p>
            </div>
            <div className="flex gap-2">
              <Button size="sm" className="bg-primary hover:bg-primary/90">
                <Sparkles className="h-3 w-3 mr-1" />
                Use AI Reply
              </Button>
              <Button size="sm" variant="outline">
                Edit & Send
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="border-t border-border bg-card p-4">
        <div className="flex items-center gap-2">
          <Button className="bg-primary hover:bg-primary/90">
            <Reply className="h-4 w-4 mr-2" />
            Reply
          </Button>
          <Button variant="outline">
            <Forward className="h-4 w-4 mr-2" />
            Forward
          </Button>
          <div className="flex-1" />
          <Button variant="ghost" size="icon">
            <Archive className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon">
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
