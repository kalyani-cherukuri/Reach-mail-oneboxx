import { useState, useMemo } from 'react';
import { AccountSidebar } from '@/components/AccountSidebar';
import { SearchBar } from '@/components/SearchBar';
import { EmailList } from '@/components/EmailList';
import { EmailDetail } from '@/components/EmailDetail';
import { Email, EmailCategory } from '@/types/email';
import { mockAccounts, mockFolders, mockEmails } from '@/lib/mockData';
import { Mail } from 'lucide-react';

const Index = () => {
  const [selectedAccountId, setSelectedAccountId] = useState<string>(mockAccounts[0].id);
  const [selectedFolder, setSelectedFolder] = useState<string>('Inbox');
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategories, setSelectedCategories] = useState<EmailCategory[]>([]);

  // Filter emails based on account, folder, search, and categories
  const filteredEmails = useMemo(() => {
    return mockEmails.filter((email) => {
      // Filter by account and folder
      if (email.accountId !== selectedAccountId || email.folder !== selectedFolder) {
        return false;
      }

      // Filter by search query
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesSearch = 
          email.subject.toLowerCase().includes(query) ||
          email.from.name.toLowerCase().includes(query) ||
          email.from.email.toLowerCase().includes(query) ||
          email.preview.toLowerCase().includes(query);
        
        if (!matchesSearch) return false;
      }

      // Filter by categories
      if (selectedCategories.length > 0) {
        if (!selectedCategories.includes(email.category)) {
          return false;
        }
      }

      return true;
    });
  }, [selectedAccountId, selectedFolder, searchQuery, selectedCategories]);

  // Auto-select first email when filters change
  useMemo(() => {
    if (filteredEmails.length > 0 && (!selectedEmail || !filteredEmails.find(e => e.id === selectedEmail.id))) {
      setSelectedEmail(filteredEmails[0]);
    } else if (filteredEmails.length === 0) {
      setSelectedEmail(null);
    }
  }, [filteredEmails]);

  return (
    <div className="h-screen flex overflow-hidden">
      {/* Account Sidebar */}
      <AccountSidebar
        accounts={mockAccounts}
        folders={mockFolders}
        selectedAccountId={selectedAccountId}
        selectedFolder={selectedFolder}
        onSelectAccount={setSelectedAccountId}
        onSelectFolder={(folder, accountId) => {
          setSelectedFolder(folder);
          setSelectedAccountId(accountId);
        }}
      />

      {/* Email List Panel */}
      <div className="w-96 border-r border-border flex flex-col bg-background">
        <SearchBar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          selectedCategories={selectedCategories}
          onCategoriesChange={setSelectedCategories}
        />
        <EmailList
          emails={filteredEmails}
          selectedEmailId={selectedEmail?.id}
          onSelectEmail={setSelectedEmail}
        />
      </div>

      {/* Email Detail Panel */}
      <div className="flex-1 bg-background">
        {selectedEmail ? (
          <EmailDetail email={selectedEmail} />
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
            <Mail className="h-16 w-16 mb-4 opacity-30" />
            <p className="text-xl font-medium">No email selected</p>
            <p className="text-sm">Select an email to view its contents</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Index;
