import { Email } from '@/types/email';
import { EmailCategoryBadge } from './EmailCategoryBadge';
import { Star, Mail } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';

interface EmailListProps {
  emails: Email[];
  selectedEmailId?: string;
  onSelectEmail: (email: Email) => void;
}

export function EmailList({ emails, selectedEmailId, onSelectEmail }: EmailListProps) {
  return (
    <div className="flex-1 overflow-y-auto">
      {emails.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-full text-muted-foreground p-8">
          <Mail className="h-12 w-12 mb-4 opacity-50" />
          <p className="text-lg font-medium">No emails found</p>
          <p className="text-sm">Try adjusting your filters or search query</p>
        </div>
      ) : (
        <div className="divide-y divide-border">
          {emails.map((email) => (
            <button
              key={email.id}
              onClick={() => onSelectEmail(email)}
              className={cn(
                "w-full text-left p-4 hover:bg-accent/50 transition-colors focus:outline-none focus:bg-accent/50",
                selectedEmailId === email.id && "bg-accent/50 border-l-2 border-primary",
                !email.read && "bg-card"
              )}
            >
              <div className="flex items-start gap-3">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    // Toggle starred
                  }}
                  className="mt-1 text-muted-foreground hover:text-primary transition-colors"
                >
                  <Star
                    className={cn(
                      "h-4 w-4",
                      email.starred && "fill-primary text-primary"
                    )}
                  />
                </button>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <div className="flex items-center gap-2 min-w-0">
                      {!email.read && (
                        <div className="h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                      )}
                      <span className={cn(
                        "font-semibold truncate",
                        !email.read && "text-foreground"
                      )}>
                        {email.from.name}
                      </span>
                    </div>
                    <span className="text-xs text-muted-foreground flex-shrink-0">
                      {formatDistanceToNow(email.date, { addSuffix: true })}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 mb-2">
                    <h3 className={cn(
                      "text-sm truncate flex-1",
                      !email.read ? "font-semibold" : "font-medium text-muted-foreground"
                    )}>
                      {email.subject}
                    </h3>
                  </div>

                  <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                    {email.preview}
                  </p>

                  <EmailCategoryBadge category={email.category} />
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
